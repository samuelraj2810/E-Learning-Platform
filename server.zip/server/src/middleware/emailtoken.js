const jwt = require("jsonwebtoken")

const emailtoken = async (){

}

module.exports=emailtoken